# Project 3: From Portland to Portland

Project Name: "From Portland to Portland"
Description:
    Functionality: 
        This site is a travel guide / bicycle-trip style blog showcasing different cities to visit in the United States, plus hawking some bicycle-related products to visitors. Includes Map/Weather/Calendar links as well.
    Technologies:
        Technologies used include Grid/flexbox positioning, linking to external resources, and advanced CSS, mainly media queries to make a responsive website starting at 320px resolution.
